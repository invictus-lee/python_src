//
//  asyncOperationProcessor.cpp
//  Proactor
//
//  Created by 李旭 on 2017/9/19.
//  Copyright © 2017年 invictuslee. All rights reserved.
//

#include <thread>
#include "asyncOperationProcessor.h"
#include "Log.h"

AsyncOperationProcessor::AsyncOperationProcessor(Proactor& proactor):
_proactor(proactor){
    
}

void AsyncOperationProcessor::async(AsyncExecutor executor,AsyncComplateHandler handler){
    std::shared_ptr<AsyncOperation> operationPtr = std::make_shared<AsyncOperation>(_proactor,executor,handler);
    _operations.push(operationPtr);
}

void AsyncOperationProcessor::run(){
    while (!_stoped) {
        while (_operations.size() > 0 ) {
            std::shared_ptr<AsyncOperation> operationPtr = _operations.front();
            std::thread thread(std::bind(&AsyncOperation::execute, operationPtr.get()));
            thread.detach();
        }
        _proactor.notify();
    }
}
void AsyncOperationProcessor::runImpl(){

    
}
void AsyncOperationProcessor::stop(){
    
}
