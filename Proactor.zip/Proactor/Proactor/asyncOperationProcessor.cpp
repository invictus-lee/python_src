//
//  asyncOperationProcessor.cpp
//  Proactor
//
//  Created by 李旭 on 2017/9/19.
//  Copyright © 2017年 invictuslee. All rights reserved.
//

#include <thread>
#include "asyncOperationProcessor.h"
#include "Log.h"

AsyncOperationProcessor::AsyncOperationProcessor(Proactor& proactor):
_proactor(proactor){
    
}

void AsyncOperationProcessor::async(AsyncExecutor executor,AsyncComplateHandler handler){
    std::shared_ptr<AsyncOperation> operationPtr = std::make_shared<AsyncOperation>(_proactor,executor,handler);
    _operations.push(operationPtr);
}

void AsyncOperationProcessor::run(){
    while (!_stoped) {

        while (_operations.size() == 0) {

            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }

        std::shared_ptr<AsyncOperation> operationPtr = _operations.front();

        _operations.pop();

        LOG_DEBUG("%s","do operation start");
        
        std::thread thread(std::bind(&AsyncOperation::execute, operationPtr.get()));

        thread.detach();

        LOG_DEBUG("%s","do operation end");
        _proactor.addCompliatedOperation(operationPtr);
    }

}
void AsyncOperationProcessor::runImpl(){

    
}
void AsyncOperationProcessor::stop(){
    
}
