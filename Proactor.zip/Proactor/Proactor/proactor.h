//
//  Proactor.h
//  Proactor
//
//  Created by 李旭 on 2017/9/19.
//  Copyright © 2017年 invictuslee. All rights reserved.
//

#ifndef Proactor_h
#define Proactor_h

#include <memory>
#include <queue>
#include "asyncOperation.h"
#include <mutex>
#include <condition_variable>

class Proactor {
    std::queue<std::shared_ptr<AsyncOperation>> _complicationQueue;
    int _maxOperation;
    std::mutex _mut;
    std::condition_variable _cond;
public:
    Proactor(int maxOperation = 20);
    void addCompliatedOperation(std::shared_ptr<AsyncOperation>);
    void notify();
};

#endif /* Proactor_h */
