//
//  asyncOperation.cpp
//  Proactor
//
//  Created by 李旭 on 2017/9/19.
//  Copyright © 2017年 invictuslee. All rights reserved.
//

#include "asyncOperation.h"
#include "proactor.h"


AsyncOperation::AsyncOperation(Proactor& proactor,AsyncExecutor executor,AsyncComplateHandler handler):_proactor(proactor),
_executor(executor),
_handler(handler)
{

}

void AsyncOperation::execute(){
    _executor();
}

void AsyncOperation::handler(){
    _handler();
}
