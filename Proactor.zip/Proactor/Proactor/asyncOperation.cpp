//
//  asyncOperation.cpp
//  Proactor
//
//  Created by 李旭 on 2017/9/19.
//  Copyright © 2017年 invictuslee. All rights reserved.
//

#include "asyncOperation.h"
#include "proactor.h"
#include "Log.h"


AsyncOperation::AsyncOperation(Proactor& proactor,AsyncExecutor executor,AsyncComplateHandler handler):_proactor(proactor),
_executor(executor),
_handler(handler)
{

}
AsyncOperation::~AsyncOperation(){
}

void AsyncOperation::execute(){
    LOG_DEBUG("%s","do operation start");
    _executor();
    _proactor.addCompliatedOperation(std::shared_ptr<AsyncOperation>(this));
    LOG_DEBUG("%s","do operation end");
}

void AsyncOperation::handler(){
    _handler();
}
