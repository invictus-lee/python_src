//
//  main.cpp
//  Proactor
//
//  Created by 李旭 on 2017/9/19.
//  Copyright © 2017年 invictuslee. All rights reserved.
//

#include <iostream>
#include <thread>
#include "proactor.h"
#include "asyncOperationProcessor.h"
#include "Log.h"

void operatorFunc(){
    std::this_thread::sleep_for(std::chrono::nanoseconds(1));
}

void operatorHandler(){
    LOG_DEBUG(" operator executed end thread id");
    std::cout<<" current thread "<<std::this_thread::get_id() <<std::endl;
}
int main(int argc, const char * argv[]) {

    std::cout<< " main thread "<< std::this_thread::get_id() <<std::endl;
    
    Proactor proactor;
    AsyncOperationProcessor  processor(proactor);
    processor.async( operatorFunc,operatorHandler);
    processor.async( operatorFunc,operatorHandler);
    processor.async( operatorFunc,operatorHandler);
    processor.async( operatorFunc,operatorHandler);
    processor.async( operatorFunc,operatorHandler);
    processor.async( operatorFunc,operatorHandler);
    processor.async( operatorFunc,operatorHandler);
    processor.async( operatorFunc,operatorHandler);
    processor.run();
    return 0;
}
