//
//  common.h
//  Proactor
//
//  Created by 李旭 on 2017/9/19.
//  Copyright © 2017年 invictuslee. All rights reserved.
//

#ifndef common_h
#define common_h

typedef  void(*AsyncComplateHandler)(void);
typedef  void(*AsyncExecutor)(void);

#endif /* common_h */
