//
//  AsynchronouseService.h
//  Proactor
//
//  Created by 李旭 on 2017/9/19.
//  Copyright © 2017年 invictuslee. All rights reserved.
//

#ifndef AsynchronouseService_h
#define AsynchronouseService_h

#include <queue>
#include "asyncOperation.h"
#include "proactor.h"
#include "common.h"

class AsyncOperationProcessor{
    typedef  std::queue<std::shared_ptr<AsyncOperation>>  AsyncOperationQueue;
    Proactor& _proactor;
    AsyncOperationQueue _operations;
    bool _stoped;
    void runImpl();
public:
    AsyncOperationProcessor(Proactor& proactor);

    void async(AsyncExecutor executor,AsyncComplateHandler handler);
    void run();
    void stop();
};

#endif /* AsynchronouseService_h */
