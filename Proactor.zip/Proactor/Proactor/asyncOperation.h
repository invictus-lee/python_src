//
//  AsynchronousOperation.h
//  Proactor
//
//  Created by 李旭 on 2017/9/19.
//  Copyright © 2017年 invictuslee. All rights reserved.
//

#ifndef AsynchronousOperation_h
#define AsynchronousOperation_h

#include "common.h"

class Proactor;
class AsyncOperation{
    Proactor& _proactor;
    AsyncExecutor _executor;
    AsyncComplateHandler _handler;
public:
    AsyncOperation(Proactor& proactor,AsyncExecutor executor,AsyncComplateHandler handler);
    void execute();
    void handler();
};

#endif /* AsynchronousOperation_h */
