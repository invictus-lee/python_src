//
//  Log.h
//  Proactor
//
//  Created by 李旭 on 2017/9/19.
//  Copyright © 2017年 invictuslee. All rights reserved.
//

#ifndef Log_h
#define Log_h

#define LOG_DEBUG(format, ...) \
    do{ \
        fprintf(stderr,"File: " __FILE__", Line: %05d: " format"\n", __LINE__, ##__VA_ARGS__); \
    }while(0)

#endif /* Log_h */
