//
//  proactor.cpp
//  Proactor
//
//  Created by 李旭 on 2017/9/19.
//  Copyright © 2017年 invictuslee. All rights reserved.
//

#include "proactor.h"


Proactor::Proactor(int maxOperation):_maxOperation(maxOperation){
}

void Proactor::addCompliatedOperation(std::shared_ptr<AsyncOperation> asyncOperationPtr){
    std::unique_lock<std::mutex> lk(_mut);
    _complicationQueue.push(asyncOperationPtr);
    _cond.notify_one();
    
}
void Proactor::notify(){
    std::unique_lock<std::mutex> lk(_mut);
    _cond.wait(lk, [this]{ return _complicationQueue.size() >0; });
    std::shared_ptr<AsyncOperation> operationPtr = _complicationQueue.front();
    operationPtr->handler();
    _complicationQueue.pop();
}
