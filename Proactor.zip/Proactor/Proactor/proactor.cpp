//
//  proactor.cpp
//  Proactor
//
//  Created by 李旭 on 2017/9/19.
//  Copyright © 2017年 invictuslee. All rights reserved.
//

#include "proactor.h"

Proactor::Proactor(int maxOperation):_maxOperation(maxOperation){
}

void Proactor::addCompliatedOperation(std::shared_ptr<AsyncOperation> asyncOperationPtr){
    asyncOperationPtr->execute();
}
